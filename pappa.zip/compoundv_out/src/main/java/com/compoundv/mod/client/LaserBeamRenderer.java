package com.compoundv.mod.client;

import com.compoundv.mod.capability.SuperPowerCapability;
import com.compoundv.mod.util.SuperPower;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.joml.Matrix4f;

import java.util.List;

@OnlyIn(Dist.CLIENT)
public class LaserBeamRenderer {

    private static final float CORE_R  = 1.0f, CORE_G  = 1.0f,  CORE_B  = 1.0f;
    private static final float INNER_R = 1.0f, INNER_G = 0.05f, INNER_B = 0.05f;
    private static final float OUTER_R = 1.0f, OUTER_G = 0.0f,  OUTER_B = 0.0f;

    private static final float CORE_ALPHA  = 1.00f;
    private static final float INNER_ALPHA = 0.85f;
    private static final float OUTER_ALPHA = 0.30f;

    // Yatay quad genislikleri
    private static final float BASE_HALF_W_CORE  = 0.010f;
    private static final float BASE_HALF_W_INNER = 0.022f;
    private static final float BASE_HALF_W_OUTER = 0.045f;

    private static final double BEAM_LENGTH = 64.0;
    private static final float  EYE_OFFSET  = 0.10f;  // iki lazer arasi mesafe

    private static final float PULSE_AMPLITUDE = 0.003f;
    private static final float PULSE_SPEED     = 3.0f;
    private static final float FLOW_SPEED      = 2.5f;

    private static final float VIGNETTE_MAX_ALPHA = 0.35f;
    private static final float VIGNETTE_PULSE     = 0.10f;

    private long startTimeMs = -1;

    // ============================================================
    //  LEVEL RENDER
    // ============================================================

    @SubscribeEvent
    public void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        Camera camera = mc.gameRenderer.getMainCamera();
        Vec3 camPos   = camera.getPosition();
        float pt      = event.getPartialTick();

        double timeSec = System.currentTimeMillis() / 1000.0;
        float pulse = (float)(Math.sin(timeSec * PULSE_SPEED) * 0.5 + 0.5);
        float flow  = (float)(Math.sin(timeSec * FLOW_SPEED + Math.PI * 0.5) * 0.5 + 0.5);

        float halfWCore  = BASE_HALF_W_CORE  + PULSE_AMPLITUDE * pulse;
        float halfWInner = BASE_HALF_W_INNER + PULSE_AMPLITUDE * pulse * 0.7f;
        float halfWOuter = BASE_HALF_W_OUTER + PULSE_AMPLITUDE * pulse * 0.5f;
        float coreAlpha  = CORE_ALPHA - 0.15f * (1.0f - flow);

        // Yatay sag vektor: sadece yaw -- her zaman yatay duzlemde sabit
        Vec3 camRight = getCameraRight(camera);

        List<? extends Player> players = mc.level.players();
        Matrix4f poseMatrix = event.getPoseStack().last().pose();

        for (Player player : players) {
            SuperPowerCapability.get(player).ifPresent(cap -> {
                if (!cap.isLaserActive()) return;
                if (!cap.hasPower(SuperPower.LASER_EYES) && !cap.hasPower(SuperPower.V24_LASER)) return;

                Vec3 eyePos = player.getEyePosition(pt);
                Vec3 look   = player.getLookAngle();

                double rx = eyePos.x - camPos.x;
                double ry = eyePos.y - camPos.y;
                double rz = eyePos.z - camPos.z;

                double ex = rx + look.x * BEAM_LENGTH;
                double ey = ry + look.y * BEAM_LENGTH;
                double ez = rz + look.z * BEAM_LENGTH;

                // Dikey vektor: yatay sag x lazer yonu
                // Bu iki vektör birlikte hangi acidan bakılırsa bakılsın
                // en az biri görünür kalır
                Vec3 up = camRight.cross(look).normalize();
                if (up.length() < 1e-4) up = new Vec3(0, 1, 0);

                beginBeamRender();
                drawDualBeam(poseMatrix, camRight, up,
                        rx, ry, rz, ex, ey, ez,
                        halfWCore, halfWInner, halfWOuter, coreAlpha);
                endBeamRender();
            });
        }
    }

    // ============================================================
    //  GUI RENDER -- vignette
    // ============================================================

    @SubscribeEvent
    public void onRenderGui(RenderGuiOverlayEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        SuperPowerCapability.get(mc.player).ifPresent(cap -> {
            if (!cap.isLaserActive()) {
                startTimeMs = -1;
                return;
            }
            if (!cap.hasPower(SuperPower.LASER_EYES) && !cap.hasPower(SuperPower.V24_LASER)) return;

            if (startTimeMs < 0) startTimeMs = System.currentTimeMillis();

            double timeSec  = System.currentTimeMillis() / 1000.0;
            float  vPulse   = (float)(Math.sin(timeSec * PULSE_SPEED * 1.3) * 0.5 + 0.5);
            float  vigAlpha = VIGNETTE_MAX_ALPHA - VIGNETTE_PULSE * vPulse;

            long elapsed = System.currentTimeMillis() - startTimeMs;
            if (elapsed < 400) vigAlpha *= elapsed / 400.0f;

            int screenW = mc.getWindow().getGuiScaledWidth();
            int screenH = mc.getWindow().getGuiScaledHeight();
            drawVignette(event.getGuiGraphics(), screenW, screenH, vigAlpha);
        });
    }

    private void drawVignette(net.minecraft.client.gui.GuiGraphics g,
                               int w, int h, float alpha) {
        int a     = (int)(alpha * 255);
        int red   = (a << 24) | 0x00CC0000;
        int clear = 0x00000000;

        com.mojang.blaze3d.vertex.PoseStack ps = g.pose();
        ps.pushPose();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        Tesselator tess = Tesselator.getInstance();
        BufferBuilder buf = tess.getBuilder();
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);

        Matrix4f m = ps.last().pose();
        int border = Math.min(w, h) / 4;

        quad(buf, m, 0,          0,          w,      border,    red,   red,   clear, clear);
        quad(buf, m, 0,          h - border, w,      h,         clear, clear, red,   red);
        quad(buf, m, 0,          0,          border, h,         red,   clear, clear, red);
        quad(buf, m, w - border, 0,          w,      h,         clear, red,   red,   clear);

        tess.end();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        ps.popPose();
    }

    private void quad(BufferBuilder buf, Matrix4f m,
                      int x1, int y1, int x2, int y2,
                      int c00, int c10, int c11, int c01) {
        buf.vertex(m, x1, y1, 0).color(cr(c00), cg(c00), cb(c00), ca(c00)).endVertex();
        buf.vertex(m, x2, y1, 0).color(cr(c10), cg(c10), cb(c10), ca(c10)).endVertex();
        buf.vertex(m, x2, y2, 0).color(cr(c11), cg(c11), cb(c11), ca(c11)).endVertex();
        buf.vertex(m, x1, y2, 0).color(cr(c01), cg(c01), cb(c01), ca(c01)).endVertex();
    }

    private int ca(int c) { return (c >> 24) & 0xFF; }
    private int cr(int c) { return (c >> 16) & 0xFF; }
    private int cg(int c) { return (c >>  8) & 0xFF; }
    private int cb(int c) { return  c        & 0xFF; }

    // ============================================================
    //  BEAM HELPERS
    // ============================================================

    private void beginBeamRender() {
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(
            org.lwjgl.opengl.GL11.GL_SRC_ALPHA, org.lwjgl.opengl.GL11.GL_ONE,
            org.lwjgl.opengl.GL11.GL_ONE,       org.lwjgl.opengl.GL11.GL_ONE
        );
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
    }

    private void endBeamRender() {
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    /**
     * Sol ve sag goz lazerleri -- her biri iki dik quad ile (cross pattern)
     * Yatay quad: camRight vektoru boyunca
     * Dikey quad: up vektoru boyunca (camRight x look)
     * Dikey quad daha ince tutulur -- asiri parlama olmaz
     */
    private void drawDualBeam(Matrix4f pose, Vec3 right, Vec3 up,
                               double ox, double oy, double oz,
                               double ex, double ey, double ez,
                               float halfWCore, float halfWInner, float halfWOuter,
                               float coreAlpha) {
        // Sol goz
        double lox = ox - right.x * EYE_OFFSET;
        double loy = oy - right.y * EYE_OFFSET;
        double loz = oz - right.z * EYE_OFFSET;
        double lex = ex - right.x * EYE_OFFSET;
        double ley = ey - right.y * EYE_OFFSET;
        double lez = ez - right.z * EYE_OFFSET;

        // Sag goz
        double rox = ox + right.x * EYE_OFFSET;
        double roy = oy + right.y * EYE_OFFSET;
        double roz = oz + right.z * EYE_OFFSET;
        double rex = ex + right.x * EYE_OFFSET;
        double rey = ey + right.y * EYE_OFFSET;
        double rez = ez + right.z * EYE_OFFSET;

        // Sol goz -- yatay + dikey quad
        drawBeamQuad(pose, right, lox, loy, loz, lex, ley, lez, halfWOuter, OUTER_R, OUTER_G, OUTER_B, OUTER_ALPHA);
        drawBeamQuad(pose, right, lox, loy, loz, lex, ley, lez, halfWInner, INNER_R, INNER_G, INNER_B, INNER_ALPHA);
        drawBeamQuad(pose, right, lox, loy, loz, lex, ley, lez, halfWCore,  CORE_R,  CORE_G,  CORE_B,  coreAlpha);
        drawBeamQuad(pose, up,    lox, loy, loz, lex, ley, lez, halfWInner, INNER_R, INNER_G, INNER_B, INNER_ALPHA * 0.6f);
        drawBeamQuad(pose, up,    lox, loy, loz, lex, ley, lez, halfWCore,  CORE_R,  CORE_G,  CORE_B,  coreAlpha);

        // Sag goz -- yatay + dikey quad
        drawBeamQuad(pose, right, rox, roy, roz, rex, rey, rez, halfWOuter, OUTER_R, OUTER_G, OUTER_B, OUTER_ALPHA);
        drawBeamQuad(pose, right, rox, roy, roz, rex, rey, rez, halfWInner, INNER_R, INNER_G, INNER_B, INNER_ALPHA);
        drawBeamQuad(pose, right, rox, roy, roz, rex, rey, rez, halfWCore,  CORE_R,  CORE_G,  CORE_B,  coreAlpha);
        drawBeamQuad(pose, up,    rox, roy, roz, rex, rey, rez, halfWInner, INNER_R, INNER_G, INNER_B, INNER_ALPHA * 0.6f);
        drawBeamQuad(pose, up,    rox, roy, roz, rex, rey, rez, halfWCore,  CORE_R,  CORE_G,  CORE_B,  coreAlpha);
    }

    private void drawBeamQuad(Matrix4f pose, Vec3 axis,
                               double ox, double oy, double oz,
                               double ex, double ey, double ez,
                               float halfW,
                               float r, float g, float b, float a) {
        Tesselator tess = Tesselator.getInstance();
        BufferBuilder buf = tess.getBuilder();
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);

        float rx = (float) axis.x * halfW;
        float ry = (float) axis.y * halfW;
        float rz = (float) axis.z * halfW;

        float sx = (float) ox, sy = (float) oy, sz = (float) oz;
        float dx = (float) ex, dy = (float) ey, dz = (float) ez;

        int ri = (int)(r * 255), gi = (int)(g * 255), bi = (int)(b * 255), ai = (int)(a * 255);

        buf.vertex(pose, sx - rx, sy - ry, sz - rz).color(ri, gi, bi, ai).endVertex();
        buf.vertex(pose, sx + rx, sy + ry, sz + rz).color(ri, gi, bi, ai).endVertex();
        buf.vertex(pose, dx + rx, dy + ry, dz + rz).color(ri, gi, bi, ai).endVertex();
        buf.vertex(pose, dx - rx, dy - ry, dz - rz).color(ri, gi, bi, ai).endVertex();

        tess.end();
    }

    // Sadece yaw -- yatay duzlemde sabit sag vektor
    // Pitch degismesi quad yonunu etkilemez
    private Vec3 getCameraRight(Camera camera) {
        float yaw = (float) Math.toRadians(camera.getYRot());
        return new Vec3(Math.cos(yaw), 0.0, -Math.sin(yaw));
    }
}
