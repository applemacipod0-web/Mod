package com.compoundv.mod.client;

import com.compoundv.mod.capability.SuperPowerCapability;
import com.compoundv.mod.util.SuperPower;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.joml.Matrix4f;

import java.util.List;

/**
 * Lazer gözler için gerçek zamanlı render efekti.
 *
 * Düzeltmeler (v1.4):
 *   1. Multiplayer: level'daki TUM oyuncuların lazeri render edilir
 *   2. getRightVector: forward x up cross product ile dogru sag vektor
 *   3. RenderSystem state: tek seferinde ac/kapat (3 katman icin)
 *   4. Lazer animasyonu: pulse (genislik titremesi) + flow (alpha dalgasi)
 *   5. Ekran efekti: lazer acikken kirmizi vignette overlay
 *
 * Katmanlar (icten disa):
 *   1. Beyaz cekirdek  -- genislik ~0.013 (pulse ile titrer)
 *   2. Kirmizi ic halo -- genislik ~0.030
 *   3. Kirmizi dis halo -- genislik ~0.065 (glow)
 */
@OnlyIn(Dist.CLIENT)
public class LaserBeamRenderer {

    // -- Renk sabitleri
    private static final float CORE_R  = 1.0f, CORE_G  = 1.0f,  CORE_B  = 1.0f;
    private static final float INNER_R = 1.0f, INNER_G = 0.05f, INNER_B = 0.05f;
    private static final float OUTER_R = 1.0f, OUTER_G = 0.0f,  OUTER_B = 0.0f;

    private static final float CORE_ALPHA  = 1.00f;
    private static final float INNER_ALPHA = 0.85f;
    private static final float OUTER_ALPHA = 0.30f;

    // -- Temel beam genislikleri (yari genislik)
    private static final float BASE_HALF_W_CORE  = 0.013f;
    private static final float BASE_HALF_W_INNER = 0.030f;
    private static final float BASE_HALF_W_OUTER = 0.065f;

    // -- Beam uzunlugu
    private static final double BEAM_LENGTH = 60.0;

    // -- Cift goz ofseti
    private static final float EYE_OFFSET = 0.06f;

    // -- Animasyon: pulse
    private static final float PULSE_AMPLITUDE = 0.004f;
    private static final float PULSE_SPEED     = 3.0f;

    // -- Animasyon: flow
    private static final float FLOW_SPEED = 2.5f;

    // -- Ekran efekti
    private static final float VIGNETTE_MAX_ALPHA = 0.35f;
    private static final float VIGNETTE_PULSE     = 0.10f;

    // -- Zaman takibi (fade-in icin)
    private long startTimeMs = -1;

    // ============================================================
    //  LEVEL RENDER -- lazer isinlari
    // ============================================================

    @SubscribeEvent
    public void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        Camera camera = mc.gameRenderer.getMainCamera();
        Vec3 camPos   = camera.getPosition();
        double pt     = event.getPartialTick();

        double timeSec = System.currentTimeMillis() / 1000.0;

        // Pulse: genislik sinuzoidal titreme
        float pulse = (float)(Math.sin(timeSec * PULSE_SPEED) * 0.5 + 0.5);
        // Flow: cekirdek alpha dalgasi
        float flow  = (float)(Math.sin(timeSec * FLOW_SPEED + Math.PI * 0.5) * 0.5 + 0.5);

        float halfWCore  = BASE_HALF_W_CORE  + PULSE_AMPLITUDE * pulse;
        float halfWInner = BASE_HALF_W_INNER + PULSE_AMPLITUDE * pulse * 0.7f;
        float halfWOuter = BASE_HALF_W_OUTER + PULSE_AMPLITUDE * pulse * 0.5f;

        float coreAlpha = CORE_ALPHA - 0.15f * (1.0f - flow);

        // FIX 1: Tum oyunculari dolastir (multiplayer destegi)
        List<? extends Player> players = mc.level.players();
        Matrix4f poseMatrix = event.getPoseStack().last().pose();

        for (Player player : players) {
            SuperPowerCapability.get(player).ifPresent(cap -> {
                if (!cap.isLaserActive()) return;
                if (!cap.hasPower(SuperPower.LASER_EYES) && !cap.hasPower(SuperPower.V24_LASER)) return;

                Vec3 eyePos = player.getEyePosition(pt);
                Vec3 look   = player.getLookAngle();

                double rx = eyePos.x - camPos.x;
                double ry = eyePos.y - camPos.y;
                double rz = eyePos.z - camPos.z;

                double ex = rx + look.x * BEAM_LENGTH;
                double ey = ry + look.y * BEAM_LENGTH;
                double ez = rz + look.z * BEAM_LENGTH;

                // FIX 2: Dogru sag vektor
                Vec3 right = getRightVector(look);

                // FIX 3: State tek seferinde aciliyor
                beginBeamRender();
                drawDualBeam(poseMatrix, right,
                        rx, ry, rz, ex, ey, ez,
                        halfWCore, halfWInner, halfWOuter, coreAlpha);
                endBeamRender();
            });
        }
    }

    // ============================================================
    //  GUI RENDER -- ekran vignette efekti
    // ============================================================

    @SubscribeEvent
    public void onRenderGui(RenderGuiOverlayEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        SuperPowerCapability.get(mc.player).ifPresent(cap -> {
            if (!cap.isLaserActive()) {
                startTimeMs = -1;
                return;
            }
            if (!cap.hasPower(SuperPower.LASER_EYES) && !cap.hasPower(SuperPower.V24_LASER)) return;

            if (startTimeMs < 0) startTimeMs = System.currentTimeMillis();

            double timeSec  = System.currentTimeMillis() / 1000.0;
            float  vPulse   = (float)(Math.sin(timeSec * PULSE_SPEED * 1.3) * 0.5 + 0.5);
            float  vigAlpha = VIGNETTE_MAX_ALPHA - VIGNETTE_PULSE * vPulse;

            // Fade-in: ilk 400ms'de yavasca belirir
            long elapsed = System.currentTimeMillis() - startTimeMs;
            if (elapsed < 400) {
                vigAlpha *= elapsed / 400.0f;
            }

            int screenW = mc.getWindow().getGuiScaledWidth();
            int screenH = mc.getWindow().getGuiScaledHeight();

            drawVignette(event.getGuiGraphics(), screenW, screenH, vigAlpha);
        });
    }

    // -- Vignette: 4 kenardan kirmizi gradient
    private void drawVignette(net.minecraft.client.gui.GuiGraphics g,
                               int w, int h, float alpha) {
        int a     = (int)(alpha * 255);
        int red   = (a << 24) | 0x00CC0000;
        int clear = 0x00000000;

        com.mojang.blaze3d.vertex.PoseStack ps = g.pose();
        ps.pushPose();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        Tesselator tess = Tesselator.getInstance();
        BufferBuilder buf = tess.getBuilder();
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);

        Matrix4f m = ps.last().pose();
        int border = Math.min(w, h) / 4;

        // Ust kenar
        quad(buf, m, 0,         0,         w,         border,    red,   red,   clear, clear);
        // Alt kenar
        quad(buf, m, 0,         h - border, w,         h,         clear, clear, red,   red);
        // Sol kenar
        quad(buf, m, 0,         0,         border,    h,         red,   clear, clear, red);
        // Sag kenar
        quad(buf, m, w - border, 0,         w,         h,         clear, red,   red,   clear);

        tess.end();

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();

        ps.popPose();
    }

    private void quad(BufferBuilder buf, Matrix4f m,
                      int x1, int y1, int x2, int y2,
                      int c00, int c10, int c11, int c01) {
        buf.vertex(m, x1, y1, 0).color(cr(c00), cg(c00), cb(c00), ca(c00)).endVertex();
        buf.vertex(m, x2, y1, 0).color(cr(c10), cg(c10), cb(c10), ca(c10)).endVertex();
        buf.vertex(m, x2, y2, 0).color(cr(c11), cg(c11), cb(c11), ca(c11)).endVertex();
        buf.vertex(m, x1, y2, 0).color(cr(c01), cg(c01), cb(c01), ca(c01)).endVertex();
    }

    private int ca(int c) { return (c >> 24) & 0xFF; }
    private int cr(int c) { return (c >> 16) & 0xFF; }
    private int cg(int c) { return (c >>  8) & 0xFF; }
    private int cb(int c) { return  c        & 0xFF; }

    // ============================================================
    //  BEAM RENDER HELPERS
    // ============================================================

    // FIX 3: State tek seferinde yonetiliyor
    private void beginBeamRender() {
        RenderSystem.enableBlend();
        // Additive blend: renkler toplanir -- dogal glow efekti
        RenderSystem.blendFuncSeparate(
            org.lwjgl.opengl.GL11.GL_SRC_ALPHA,           org.lwjgl.opengl.GL11.GL_ONE,
            org.lwjgl.opengl.GL11.GL_ONE,                 org.lwjgl.opengl.GL11.GL_ONE
        );
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
    }

    private void endBeamRender() {
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    private void drawDualBeam(Matrix4f pose, Vec3 right,
                               double ox, double oy, double oz,
                               double ex, double ey, double ez,
                               float halfWCore, float halfWInner, float halfWOuter,
                               float coreAlpha) {
        // Sol goz
        drawBeamLayers(pose, right,
                ox - right.x * EYE_OFFSET, oy - right.y * EYE_OFFSET, oz - right.z * EYE_OFFSET,
                ex - right.x * EYE_OFFSET, ey - right.y * EYE_OFFSET, ez - right.z * EYE_OFFSET,
                halfWCore, halfWInner, halfWOuter, coreAlpha);

        // Sag goz
        drawBeamLayers(pose, right,
                ox + right.x * EYE_OFFSET, oy + right.y * EYE_OFFSET, oz + right.z * EYE_OFFSET,
                ex + right.x * EYE_OFFSET, ey + right.y * EYE_OFFSET, ez + right.z * EYE_OFFSET,
                halfWCore, halfWInner, halfWOuter, coreAlpha);
    }

    private void drawBeamLayers(Matrix4f pose, Vec3 right,
                                 double ox, double oy, double oz,
                                 double ex, double ey, double ez,
                                 float halfWCore, float halfWInner, float halfWOuter,
                                 float coreAlpha) {
        drawBeamQuad(pose, right, ox, oy, oz, ex, ey, ez,
                halfWOuter, OUTER_R, OUTER_G, OUTER_B, OUTER_ALPHA);
        drawBeamQuad(pose, right, ox, oy, oz, ex, ey, ez,
                halfWInner, INNER_R, INNER_G, INNER_B, INNER_ALPHA);
        drawBeamQuad(pose, right, ox, oy, oz, ex, ey, ez,
                halfWCore, CORE_R, CORE_G, CORE_B, coreAlpha);
    }

    private void drawBeamQuad(Matrix4f pose, Vec3 right,
                               double ox, double oy, double oz,
                               double ex, double ey, double ez,
                               float halfW,
                               float r, float g, float b, float a) {

        Tesselator tess = Tesselator.getInstance();
        BufferBuilder buf = tess.getBuilder();
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);

        float rx = (float) right.x * halfW;
        float ry = (float) right.y * halfW;
        float rz = (float) right.z * halfW;

        float sx = (float) ox, sy = (float) oy, sz = (float) oz;
        float dx = (float) ex, dy = (float) ey, dz = (float) ez;

        int ri = (int)(r * 255), gi = (int)(g * 255), bi = (int)(b * 255), ai = (int)(a * 255);

        buf.vertex(pose, sx - rx, sy - ry, sz - rz).color(ri, gi, bi, ai).endVertex();
        buf.vertex(pose, sx + rx, sy + ry, sz + rz).color(ri, gi, bi, ai).endVertex();
        buf.vertex(pose, dx + rx, dy + ry, dz + rz).color(ri, gi, bi, ai).endVertex();
        buf.vertex(pose, dx - rx, dy - ry, dz - rz).color(ri, gi, bi, ai).endVertex();

        tess.end();
    }

    // ============================================================
    //  FIX 2: Dogru sag vektor -- forward x worldUp cross product
    // ============================================================
    /**
     * Eski yontem sadece yaw kullaniyordu, pitch degisiminde quad kayiyordu.
     * Yeni yontem: look x (0,1,0) -- her bakis acisinda kararli.
     * Tam dikey bakista (90 derece yukari/asagi) fallback olarak (1,0,0) kullanilir.
     */
    private Vec3 getRightVector(Vec3 look) {
        Vec3 worldUp = new Vec3(0, 1, 0);
        Vec3 right   = look.cross(worldUp);
        double len   = right.length();
        if (len < 1e-4) {
            return new Vec3(1, 0, 0); // tam dikey bakis fallback
        }
        return right.scale(1.0 / len);
    }
}
