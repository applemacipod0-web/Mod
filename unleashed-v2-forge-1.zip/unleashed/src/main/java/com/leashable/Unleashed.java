package com.leashable;

import com.leashable.event.LeashEventHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod("unleashed")
public class Unleashed {

    public static final String MOD_ID = "unleashed";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    public Unleashed() {
        MinecraftForge.EVENT_BUS.register(new LeashEventHandler());
        LOGGER.info("Unleashed loaded! All mobs can now be leashed.");
    }
}
