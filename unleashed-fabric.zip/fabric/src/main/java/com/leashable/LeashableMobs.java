package com.leashable;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LeashableMobs implements ModInitializer {
    public static final String MOD_ID = "leashable_mobs";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Unleashed loaded!");
    }
}
