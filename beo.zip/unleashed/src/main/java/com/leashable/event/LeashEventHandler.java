package com.leashable.event;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.monster.hoglin.Hoglin;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.entity.animal.Turtle;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Set;

public class LeashEventHandler {

    private static final Set<Class<? extends LivingEntity>> LEASHABLE = Set.of(
        Villager.class,
        ZombieVillager.class,
        WanderingTrader.class,
        Witch.class,
        Pillager.class,
        Vindicator.class,
        Evoker.class,
        Turtle.class,
        Creeper.class,
        Zombie.class,
        Skeleton.class,
        EnderMan.class,
        Spider.class,
        Piglin.class,
        Hoglin.class
    );

    @SubscribeEvent
    public void onPlayerInteractEntity(PlayerInteractEvent.EntityInteract event) {
        // ServerLevel kontrolü — hem singleplayer hem multiplayer'da doğru çalışır.
        // isClientSide() singleplayer'da yanlış sonuç veriyordu.
        if (!(event.getEntity().level() instanceof ServerLevel)) return;

        Entity target = event.getTarget();
        var player = event.getEntity();

        boolean mainHand = player.getMainHandItem().is(Items.LEAD);
        boolean offHand  = player.getOffhandItem().is(Items.LEAD);
        if (!mainHand && !offHand) return;

        if (!isLeashableMob(target)) return;

        if (!(target instanceof Mob mob)) return;
        if (mob.getLeashHolder() != null) return;

        mob.setLeashedTo(player, true);

        if (!player.isCreative()) {
            InteractionHand hand = mainHand ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
            player.getItemInHand(hand).shrink(1);
        }

        event.setCanceled(true);
    }

    private boolean isLeashableMob(Entity entity) {
        for (Class<? extends LivingEntity> clazz : LEASHABLE) {
            if (clazz.isInstance(entity)) return true;
        }
        return false;
    }
}
