package com.leashable;

import net.minecraftforge.fml.common.Mod;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod("unleashed")
public class Unleashed {

    public static final String MOD_ID = "unleashed";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    public Unleashed() {
        // Mixin otomatik yükleniyor, event handler'a gerek yok
        LOGGER.info("Unleashed loaded! All mobs can now be leashed.");
    }
}
