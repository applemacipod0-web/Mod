package com.leashable.mixin;

import net.minecraft.world.entity.monster.Evoker;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Evoker.class)
public abstract class EvokerMixin {
    @Inject(method = "canBeLeashedBy", at = @At("HEAD"), cancellable = true, require = 0)
    private void unleashed_canBeLeashedBy(Player player, CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(true);
    }
}
