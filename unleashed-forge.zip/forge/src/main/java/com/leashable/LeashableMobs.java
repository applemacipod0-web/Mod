package com.leashable;

import net.minecraftforge.fml.common.Mod;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod("leashable_mobs")
public class LeashableMobs {
    public static final String MOD_ID = "leashable_mobs";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    public LeashableMobs() {
        LOGGER.info("Unleashed loaded!");
    }
}
