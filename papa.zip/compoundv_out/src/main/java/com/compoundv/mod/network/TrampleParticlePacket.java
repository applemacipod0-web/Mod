package com.compoundv.mod.network;

import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.network.NetworkEvent;

import java.util.Random;
import java.util.function.Supplier;

/**
 * Hızlı koşmada canlı ezildiğinde kırmızı kan partikülleri gösterir.
 * Server → Client
 */
public class TrampleParticlePacket {

    private final double x, y, z;

    public TrampleParticlePacket(double x, double y, double z) {
        this.x = x; this.y = y; this.z = z;
    }

    public static void encode(TrampleParticlePacket p, FriendlyByteBuf buf) {
        buf.writeDouble(p.x); buf.writeDouble(p.y); buf.writeDouble(p.z);
    }

    public static TrampleParticlePacket decode(FriendlyByteBuf buf) {
        return new TrampleParticlePacket(buf.readDouble(), buf.readDouble(), buf.readDouble());
    }

    public static void handle(TrampleParticlePacket packet, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> handleClient(packet));
        ctx.get().setPacketHandled(true);
    }

    @OnlyIn(Dist.CLIENT)
    private static void handleClient(TrampleParticlePacket p) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Random rand = new Random();

        // Kırmızı DUST partikülleri (kan efekti)
        net.minecraft.core.particles.DustParticleOptions red =
            new net.minecraft.core.particles.DustParticleOptions(
                new org.joml.Vector3f(1.0f, 0.0f, 0.0f), 1.2f
            );

        // Kan sıçrama - 30 kırmızı parçacık
        for (int i = 0; i < 30; i++) {
            double vx = (rand.nextDouble() - 0.5) * 0.6;
            double vy = rand.nextDouble() * 0.5 + 0.1;
            double vz = (rand.nextDouble() - 0.5) * 0.6;
            mc.level.addParticle(red,
                p.x + (rand.nextDouble() - 0.5) * 0.4,
                p.y,
                p.z + (rand.nextDouble() - 0.5) * 0.4,
                vx, vy, vz);
        }

        // Küçük CRIT parçacıkları (çarpma hissi)
        for (int i = 0; i < 8; i++) {
            mc.level.addParticle(ParticleTypes.CRIT,
                p.x + (rand.nextDouble() - 0.5) * 0.3,
                p.y + 0.3,
                p.z + (rand.nextDouble() - 0.5) * 0.3,
                (rand.nextDouble() - 0.5) * 0.4,
                rand.nextDouble() * 0.3,
                (rand.nextDouble() - 0.5) * 0.4);
        }
    }
}
