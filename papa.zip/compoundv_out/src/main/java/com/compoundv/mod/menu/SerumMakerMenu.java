package com.compoundv.mod.menu;

import com.compoundv.mod.blockentity.SerumMakerBlockEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.items.SlotItemHandler;

public class SerumMakerMenu extends AbstractContainerMenu {

    private final SerumMakerBlockEntity blockEntity;
    private final ContainerData data;

    // Client tarafı constructor
    public SerumMakerMenu(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, getBlockEntity(inv, buf), new SimpleContainerData(2));
    }

    private static SerumMakerBlockEntity getBlockEntity(Inventory inv, FriendlyByteBuf buf) {
        BlockEntity be = inv.player.level().getBlockEntity(buf.readBlockPos());
        if (be instanceof SerumMakerBlockEntity serumBE) return serumBE;
        throw new IllegalStateException("SerumMakerBlockEntity beklendi ama bulunamadı!");
    }

    // Server tarafı constructor
    public SerumMakerMenu(int id, Inventory inv, SerumMakerBlockEntity be, ContainerData data) {
        super(ModMenuTypes.SERUM_MAKER.get(), id);
        this.blockEntity = be;
        this.data = data;

        addPlayerInventory(inv);
        addPlayerHotbar(inv);

        be.getCapability(ForgeCapabilities.ITEM_HANDLER).ifPresent(handler -> {
            // 3 girdi slotu - sol tarafta yan yana (texture ile hizalı)
            this.addSlot(new SlotItemHandler(handler, 0, 26, 26));  // Sol  (Raw Compound V)
            this.addSlot(new SlotItemHandler(handler, 1, 44, 26));  // Orta (Stabilizer)
            this.addSlot(new SlotItemHandler(handler, 2, 62, 26));  // Sag  (Diamond)

            // Cikti slotu - sagda (texture ile hizali)
            this.addSlot(new SlotItemHandler(handler, 3, 134, 26) {
                @Override
                public boolean mayPlace(ItemStack stack) { return false; } // sadece cikti
            });
        });

        addDataSlots(data);
    }

    // Progress bar için
    public boolean isCrafting() {
        return data.get(0) > 0;
    }

    public int getScaledProgress() {
        int progress = data.get(0);
        int maxProgress = data.get(1);
        int progressBarSize = 26; // pixel genişliği
        return maxProgress != 0 ? progress * progressBarSize / maxProgress : 0;
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(ContainerLevelAccess.create(blockEntity.getLevel(),
                blockEntity.getBlockPos()), player, blockEntity.getBlockState().getBlock());
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack returnStack = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);

        if (slot.hasItem()) {
            ItemStack slotStack = slot.getItem();
            returnStack = slotStack.copy();

            // Çıktı slotundan (3) player envanterine
            if (index == 3) {
                if (!this.moveItemStackTo(slotStack, 4, 40, true)) return ItemStack.EMPTY;
                slot.onQuickCraft(slotStack, returnStack);
            }
            // Player envanterinden girdi slotlarına (0-2)
            else if (index >= 4) {
                if (!this.moveItemStackTo(slotStack, 0, 3, false)) return ItemStack.EMPTY;
            }
            // Girdi slotlarından player envanterine
            else {
                if (!this.moveItemStackTo(slotStack, 4, 40, false)) return ItemStack.EMPTY;
            }

            if (slotStack.isEmpty()) slot.set(ItemStack.EMPTY);
            else slot.setChanged();

            if (slotStack.getCount() == returnStack.getCount()) return ItemStack.EMPTY;
            slot.onTake(player, slotStack);
        }

        return returnStack;
    }

    private void addPlayerInventory(Inventory inv) {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(inv, col + row * 9 + 9, 7 + col * 18, 84 + row * 18));
            }
        }
    }

    private void addPlayerHotbar(Inventory inv) {
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(inv, col, 7 + col * 18, 142));
        }
    }
}
