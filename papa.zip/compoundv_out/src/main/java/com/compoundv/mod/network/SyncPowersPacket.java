package com.compoundv.mod.network;

import com.compoundv.mod.capability.SuperPowerCapability;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SyncPowersPacket {

    private final CompoundTag data;

    public SyncPowersPacket(CompoundTag data) {
        this.data = data;
    }

    public static void encode(SyncPowersPacket packet, FriendlyByteBuf buf) {
        buf.writeNbt(packet.data);
    }

    public static SyncPowersPacket decode(FriendlyByteBuf buf) {
        return new SyncPowersPacket(buf.readNbt());
    }

    public static void handle(SyncPowersPacket packet, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> handleClient(packet));
        ctx.get().setPacketHandled(true);
    }

    @OnlyIn(Dist.CLIENT)
    private static void handleClient(SyncPowersPacket packet) {
        Player player = Minecraft.getInstance().player;
        if (player != null) {
            SuperPowerCapability.get(player).ifPresent(cap -> {
                cap.deserializeNBT(packet.data);
            });
        }
    }
}
