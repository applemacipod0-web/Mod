package com.compoundv.mod.command;

import com.compoundv.mod.capability.SuperPowerCapability;
import com.compoundv.mod.network.PacketHandler;
import com.compoundv.mod.network.SyncPowersPacket;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.PacketDistributor;

public class ModCommands {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("compoundv")
            .then(Commands.literal("reset")
                .executes(ctx -> {
                    Player player = ctx.getSource().getPlayerOrException();

                    SuperPowerCapability.get(player).ifPresent(cap -> {
                        cap.clearPowers();

                        cap.setFlying(false);
                        cap.setLaserActive(false);
                        cap.setLightningActive(false);
                        cap.setNuclearCharged(false);

                        player.getAbilities().mayfly = false;
                        player.getAbilities().flying = false;
                        player.setNoGravity(false);
                        player.onUpdateAbilities();

                        player.removeEffect(MobEffects.DAMAGE_RESISTANCE);
                        player.removeEffect(MobEffects.DAMAGE_BOOST);
                        player.removeEffect(MobEffects.HEALTH_BOOST);
                        player.removeEffect(MobEffects.FIRE_RESISTANCE);
                        player.removeEffect(MobEffects.REGENERATION);
                        player.removeEffect(MobEffects.MOVEMENT_SPEED);

                        if (player instanceof ServerPlayer serverPlayer) {
                            PacketHandler.CHANNEL.send(
                                PacketDistributor.PLAYER.with(() -> serverPlayer),
                                new SyncPowersPacket(cap.serializeNBT())
                            );
                        }
                    });

                    ctx.getSource().sendSuccess(() ->
                        Component.literal("§a✔ Compound V güçleri sıfırlandı. Artık tekrar V1 içebilirsin."),
                        false
                    );
                    return 1;
                })
            )
        );
    }
}
