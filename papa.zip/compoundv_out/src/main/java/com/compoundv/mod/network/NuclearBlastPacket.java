package com.compoundv.mod.network;

import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.network.NetworkEvent;

import java.util.Random;
import java.util.function.Supplier;

/**
 * Nükleer patlama görsel efektini client tarafında oynatır.
 * Sunucu → İstemci yönünde gönderilir.
 */
public class NuclearBlastPacket {

    private final double x;
    private final double y;
    private final double z;

    public NuclearBlastPacket(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public static void encode(NuclearBlastPacket packet, FriendlyByteBuf buf) {
        buf.writeDouble(packet.x);
        buf.writeDouble(packet.y);
        buf.writeDouble(packet.z);
    }

    public static NuclearBlastPacket decode(FriendlyByteBuf buf) {
        return new NuclearBlastPacket(buf.readDouble(), buf.readDouble(), buf.readDouble());
    }

    public static void handle(NuclearBlastPacket packet, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> handleClient(packet));
        ctx.get().setPacketHandled(true);
    }

    @OnlyIn(Dist.CLIENT)
    private static void handleClient(NuclearBlastPacket packet) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;

        Random rand = new Random();
        Vec3 center = new Vec3(packet.x, packet.y, packet.z);

        // Büyük patlama dairesi — 150 parçacık, 15 blok yarıçap
        for (int i = 0; i < 150; i++) {
            double angle = rand.nextDouble() * Math.PI * 2;
            double radius = rand.nextDouble() * 15.0;
            double height = rand.nextDouble() * 6.0;
            double px = center.x + Math.cos(angle) * radius;
            double py = center.y + height;
            double pz = center.z + Math.sin(angle) * radius;
            mc.level.addParticle(ParticleTypes.EXPLOSION_EMITTER, px, py, pz, 0, 0, 0);
        }

        // Ateş parçacıkları
        for (int i = 0; i < 80; i++) {
            double px = center.x + (rand.nextDouble() - 0.5) * 20;
            double py = center.y + rand.nextDouble() * 8;
            double pz = center.z + (rand.nextDouble() - 0.5) * 20;
            mc.level.addParticle(ParticleTypes.FLAME, px, py, pz,
                    (rand.nextDouble() - 0.5) * 0.3,
                    rand.nextDouble() * 0.5,
                    (rand.nextDouble() - 0.5) * 0.3);
        }

        // Duman sütunu
        for (int i = 0; i < 60; i++) {
            double py = center.y + i * 0.3;
            double spread = Math.min(i * 0.2, 4.0);
            double px = center.x + (rand.nextDouble() - 0.5) * spread;
            double pz = center.z + (rand.nextDouble() - 0.5) * spread;
            mc.level.addParticle(ParticleTypes.LARGE_SMOKE, px, py, pz, 0, 0.05, 0);
        }
    }
}
