package com.compoundv.mod.item;

import com.compoundv.mod.capability.SuperPowerCapability;
import com.compoundv.mod.network.PacketHandler;
import com.compoundv.mod.network.SyncPowersPacket;
import com.compoundv.mod.util.SuperPower;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Random;

public class SerumV1Item extends Item {

    public SerumV1Item() {
        super(new Item.Properties()
                .stacksTo(1)
                .fireResistant());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (!level.isClientSide()) {
            SuperPowerCapability.get(player).ifPresent(cap -> {
                int currentDose = cap.getV1DrinkCount();

                // 3 dozdan fazla içilemez
                if (currentDose >= 3) {
                    player.sendSystemMessage(Component.literal(
                        "§4§l☠ MAKSİMUM DOZ! §r§cV1 artık vücuduna işlemiyor, daha fazlası öldürür."
                    ));
                    return;
                }

                // V1 serumunu uygula (içeride count artar)
                cap.lastGainedPower = null;
                cap.applyV1Serum(new Random());

                int newDose = cap.getV1DrinkCount(); // artık 1, 2 veya 3

                // Ses efekti
                level.playSound(null, player.blockPosition(),
                        SoundEvents.HONEY_DRINK, SoundSource.PLAYERS, 1.0f, 0.8f);

                if (newDose == 1) {
                    // İlk içiş mesajları
                    player.sendSystemMessage(Component.literal("§c§l⚡ V1 SERUMU ENJEKSİYON! [1/3] §r")
                            .withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
                    player.sendSystemMessage(Component.literal("§eZorunlu güçler aktif: §cÖlümsüze Yakın Dayanıklılık, Süper Güç"));

                    StringBuilder randomPowers = new StringBuilder("§aRastgele güçler: §f");
                    boolean hasRandom = false;
                    for (SuperPower power : cap.getActivePowers()) {
                        if (power.tier == SuperPower.PowerTier.RARE ||
                            power.tier == SuperPower.PowerTier.UNCOMMON) {
                            randomPowers.append(power.displayName).append(", ");
                            hasRandom = true;
                        }
                    }
                    if (hasRandom) {
                        player.sendSystemMessage(Component.literal(randomPowers.toString()));
                    } else {
                        player.sendSystemMessage(Component.literal("§7Rastgele güç kazanılmadı bu seferlik."));
                    }
                    if (cap.hasPower(SuperPower.SOLDIER_SIZE)) {
                        player.sendSystemMessage(Component.literal(
                            "§6§l★ Soldier Boy boyutuna ulaştın! (x" +
                            String.format("%.1f", cap.getSizeMultiplier()) + ")")
                        );
                    }
                    player.sendSystemMessage(Component.literal("§b§lTuş Atamaları: §rZ=Nükleer Patlama | G=Uçuş | H=Lazer Göz | N=Yıldırım"));

                } else {
                    // 2. veya 3. içiş
                    player.sendSystemMessage(Component.literal(
                        "§c§l⚡ V1 GÜÇLEME DOZU [" + newDose + "/3] §r"
                    ).withStyle(ChatFormatting.RED, ChatFormatting.BOLD));

                    if (cap.getPowerAmplifier() > 0) {
                        // %80 güçlenme yolu
                        player.sendSystemMessage(Component.literal(
                            "§a✦ Güçlerin §l" + (cap.getPowerAmplifier() == 1 ? "Seviye 2" : "Seviye 3 (MAX)") +
                            "§r§a'ye yükseldi! (%80 şans gerçekleşti)"
                        ));
                        if (cap.hasPower(SuperPower.SOLDIER_SIZE)) {
                            player.sendSystemMessage(Component.literal(
                                "§6★ Asker boyutu: x" + String.format("%.1f", cap.getSizeMultiplier())
                            ));
                        }
                    } else if (cap.lastGainedPower != null) {
                        // %20 yeni güç yolu
                        player.sendSystemMessage(Component.literal(
                            "§d✦ Yeni güç kazandın (%20 şans): §f" + cap.lastGainedPower.displayName
                        ));
                    } else {
                        player.sendSystemMessage(Component.literal("§7Zaten tüm güçlere sahipsin, güçlenme etkisiz."));
                    }

                    if (newDose == 3) {
                        player.sendSystemMessage(Component.literal("§4⚠ Bu son dozundu! Artık daha fazla V1 içemezsin."));
                    }
                }

                // İstemciye senkronize et
                if (player instanceof ServerPlayer serverPlayer) {
                    PacketHandler.CHANNEL.send(
                        PacketDistributor.PLAYER.with(() -> serverPlayer),
                        new SyncPowersPacket(cap.serializeNBT())
                    );
                }
            });

            // Serumu tüket
            stack.shrink(1);
        }

        return InteractionResultHolder.success(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§c§lV1 SERUMU").withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
        tooltip.add(Component.literal("§7Vought International tarafından üretilmiştir.").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.empty());
        tooltip.add(Component.literal("§a[1. Doz] İlk içiş:").withStyle(ChatFormatting.GREEN));
        tooltip.add(Component.literal("§f• Ölümsüze Yakın Dayanıklılık + Süper Güç (zorunlu)").withStyle(ChatFormatting.WHITE));
        tooltip.add(Component.literal("§f• %20 Lazer/Uçma/Yıldırım | %40 Sürat/Yenilenme").withStyle(ChatFormatting.WHITE));
        tooltip.add(Component.literal("§6• %20 Soldier Boy paketi (Boyut + Nükleer Patlama Z)").withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.empty());
        tooltip.add(Component.literal("§e[2. ve 3. Doz] Güçlendirme:").withStyle(ChatFormatting.YELLOW));
        tooltip.add(Component.literal("§f• %80 → Mevcut güçler bir seviye yükselir").withStyle(ChatFormatting.WHITE));
        tooltip.add(Component.literal("§d• %20 → Yeni rastgele bir güç kazanırsın").withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.empty());
        tooltip.add(Component.literal("§4⚠ Maksimum 3 doz! 4. içişte etkisiz.").withStyle(ChatFormatting.DARK_RED));
        tooltip.add(Component.literal("§c⚠ Sadece Serum Maker'da üretilir!").withStyle(ChatFormatting.RED));
    }
}
