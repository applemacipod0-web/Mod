package com.compoundv.mod.event;

import com.compoundv.mod.capability.SuperPowerCapability;
import com.compoundv.mod.client.ModKeyBindings;
import com.compoundv.mod.network.PacketHandler;
import com.compoundv.mod.network.KeyActionPacket;
import com.compoundv.mod.util.SuperPower;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

@OnlyIn(Dist.CLIENT)
public class KeyInputHandler {

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null) return;

        Player player = mc.player;

        // === Z - NÜKLEER PATLAMA ===
        if (ModKeyBindings.NUCLEAR_BLAST.consumeClick()) {
            SuperPowerCapability.get(player).ifPresent(cap -> {
                if (cap.hasPower(SuperPower.NUCLEAR_BLAST)) {
                    PacketHandler.CHANNEL.sendToServer(new KeyActionPacket(KeyActionPacket.Action.NUCLEAR_BLAST));
                }
            });
        }

        // === G - UÇMA TOGGLE ===
        if (ModKeyBindings.TOGGLE_FLIGHT.consumeClick()) {
            SuperPowerCapability.get(player).ifPresent(cap -> {
                if (cap.hasPower(SuperPower.FLIGHT)) {
                    PacketHandler.CHANNEL.sendToServer(new KeyActionPacket(KeyActionPacket.Action.TOGGLE_FLIGHT));
                }
            });
        }

        // === H - LAZER GÖZ TOGGLE ===
        if (ModKeyBindings.TOGGLE_LASER.consumeClick()) {
            SuperPowerCapability.get(player).ifPresent(cap -> {
                if (cap.hasPower(SuperPower.LASER_EYES) || cap.hasPower(SuperPower.V24_LASER)) {
                    PacketHandler.CHANNEL.sendToServer(new KeyActionPacket(KeyActionPacket.Action.TOGGLE_LASER));
                }
            });
        }

        // === N - YILDIRIM KONTROLÜ (Stormfront) ===
        if (ModKeyBindings.TOGGLE_LIGHTNING.consumeClick()) {
            SuperPowerCapability.get(player).ifPresent(cap -> {
                if (cap.hasPower(SuperPower.LIGHTNING_CONTROL)) {
                    PacketHandler.CHANNEL.sendToServer(new KeyActionPacket(KeyActionPacket.Action.TOGGLE_LIGHTNING));
                }
            });
        }
    }
}
