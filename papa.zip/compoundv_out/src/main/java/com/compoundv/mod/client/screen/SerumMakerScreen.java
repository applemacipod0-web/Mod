package com.compoundv.mod.client.screen;

import com.compoundv.mod.CompoundVMod;
import com.compoundv.mod.menu.SerumMakerMenu;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

public class SerumMakerScreen extends AbstractContainerScreen<SerumMakerMenu> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(CompoundVMod.MOD_ID, "textures/gui/serum_maker.png");

    // GUI boyutu
    private static final int GUI_WIDTH = 176;
    private static final int GUI_HEIGHT = 166;

    public SerumMakerScreen(SerumMakerMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = GUI_WIDTH;
        this.imageHeight = GUI_HEIGHT;
    }

    @Override
    protected void init() {
        super.init();
        // Başlık pozisyonları
        this.titleLabelX = (this.imageWidth - this.font.width(this.title)) / 2;
        this.titleLabelY = 6;
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.setShaderTexture(0, TEXTURE);

        int x = this.leftPos;
        int y = this.topPos;

        // Ana GUI arka planı
        graphics.blit(TEXTURE, x, y, 0, 0, this.imageWidth, this.imageHeight);

        // Progress bar (ok animasyonu)
        // Atlas: bos ok 176,0 konumunda; dolu ok 176,16 konumunda; her ikisi 26x16 piksel
        // Ok: girdi slotlari bitis x=80, cikti baslangic x=134
        // Ok merkez: (80+134)/2=107, genislik 26 → baslangic x=94
        // Slot merkez y: 26+9=35, ok yukseklik 16 → baslangic y=27
        int arrowX = x + 94;
        int arrowY = y + 27;
        graphics.blit(TEXTURE, arrowX, arrowY, 176, 0, 26, 16);
        if (this.menu.isCrafting()) {
            int progress = this.menu.getScaledProgress(); // 0-26 arasi
            graphics.blit(TEXTURE, arrowX, arrowY, 176, 16, progress, 16);
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        this.renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, delta);
        this.renderTooltip(graphics, mouseX, mouseY);
    }
}
