package com.compoundv.mod.network;

import com.compoundv.mod.capability.SuperPowerCapability;
import com.compoundv.mod.util.SuperPower;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.List;
import java.util.function.Supplier;

public class KeyActionPacket {

    public enum Action {
        NUCLEAR_BLAST,
        TOGGLE_FLIGHT,
        TOGGLE_LASER,
        TOGGLE_LIGHTNING
    }

    private final Action action;

    public KeyActionPacket(Action action) {
        this.action = action;
    }

    public static void encode(KeyActionPacket packet, FriendlyByteBuf buf) {
        buf.writeEnum(packet.action);
    }

    public static KeyActionPacket decode(FriendlyByteBuf buf) {
        return new KeyActionPacket(buf.readEnum(Action.class));
    }

    public static void handle(KeyActionPacket packet, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;

            SuperPowerCapability.get(player).ifPresent(cap -> {
                switch (packet.action) {

                    case NUCLEAR_BLAST -> {
                        if (cap.hasPower(SuperPower.NUCLEAR_BLAST)) {
                            // Şarjı başlat (PlayerEventHandler her tick sayacı artırır)
                            if (cap.getNuclearCooldownTicks() > 0) {
                                int remaining = cap.getNuclearCooldownTicks() / 20;
                                player.sendSystemMessage(Component.literal(
                                    "§4☢ Nükleer güç bekleme süresinde! §c" + remaining + " saniye kaldı."
                                ));
                            } else if (!cap.isNuclearCharging()) {
                                cap.setNuclearCharging(true);
                                cap.setNuclearChargeTicks(0);
                                player.sendSystemMessage(Component.literal(
                                    "§e☢ Şarj başladı! 50 saniye dolduğunda otomatik ateşlenecek."
                                ));
                            }
                        }
                    }

                    case TOGGLE_FLIGHT -> {
                        if (cap.hasPower(SuperPower.FLIGHT)) {
                            boolean nowFlying = !cap.isFlying();
                            cap.setFlying(nowFlying);
                            player.getAbilities().mayfly = nowFlying;
                            player.getAbilities().flying = nowFlying;
                            player.setNoGravity(nowFlying);
                            player.onUpdateAbilities();
                            player.sendSystemMessage(Component.literal(
                                nowFlying ? "§a✈ Uçma: AKTİF" : "§c✈ Uçma: PASİF"
                            ));
                        }
                    }

                    case TOGGLE_LASER -> {
                        if (cap.hasPower(SuperPower.LASER_EYES) || cap.hasPower(SuperPower.V24_LASER)) {
                            if (!cap.isLaserActive()) {
                                // Açmaya çalışıyor — yorgunluk kontrolü
                                if (cap.getLaserFatigueTicks() > 0) {
                                    player.sendSystemMessage(Component.literal(
                                        "§7🔴 Lazer gözler dinleniyor... (" + (cap.getLaserFatigueTicks() / 20 + 1) + "sn)"
                                    ));
                                } else {
                                    cap.setLaserActive(true);
                                    player.sendSystemMessage(Component.literal("§c🔴 Lazer: AKTİF (max 5sn sürekli)"));
                                }
                            } else {
                                // Kapat
                                cap.setLaserActive(false);
                                player.sendSystemMessage(Component.literal("§7🔴 Lazer: KAPALI"));
                            }
                        }
                    }

                    case TOGGLE_LIGHTNING -> {
                        if (cap.hasPower(SuperPower.LIGHTNING_CONTROL)) {
                            if (cap.getLightningCooldownTicks() > 0) {
                                int secs = (cap.getLightningCooldownTicks() / 20) + 1;
                                player.sendSystemMessage(Component.literal(
                                    "§7⚡ Yıldırım bekleme: §e" + secs + " saniye"
                                ));
                            } else if (player.level() instanceof ServerLevel serverLevel) {
                                strikeNearbyWithLightning(player, serverLevel);
                                cap.setLightningCooldownTicks(200); // 10 saniye cooldown
                                player.sendSystemMessage(Component.literal("§e⚡ Stormfront Yıldırım Saldırısı!"));
                            }
                        }
                    }
                }
            });
        });
        ctx.get().setPacketHandled(true);
    }

    // ===================== NÜKLEER PATLAMA =====================
    private static void performNuclearBlast(ServerPlayer player) {
        if (!(player.level() instanceof ServerLevel serverLevel)) return;

        Vec3 pos = player.position();

        // Patlama oyuncunun kendisinden çıkıyor (Soldier Boy gibi göğsünden/vücudundan)
        // ExplosionInteraction.NONE → blok hasarı vermez, sadece varlıklara
        serverLevel.explode(null, pos.x, pos.y + 0.5, pos.z,
            7.0f, false, Level.ExplosionInteraction.NONE);

        // 15 blok yarıçapındaki düşman varlıkları öldür (oyuncular ve pasif hayvanlar hariç)
        // Patlama 15 blok yaricapindaki TUM canli varliklara vurur
        // Patlatici oyuncu HARIC, diger oyuncular DAHIL
        AABB blastZone = player.getBoundingBox().inflate(15.0);
        List<LivingEntity> victims = player.level().getEntitiesOfClass(
            LivingEntity.class, blastZone,
            e -> e != player
        );
        for (LivingEntity entity : victims) {
            entity.hurt(player.level().damageSources().explosion(null), 500.0f);
        }

        // Soldier Boy kendine HASAR ALMAZ - sadece geri tepme efekti
        player.push(0, 0.8, 0);

        player.sendSystemMessage(Component.literal("§c§l☢ NÜKLEER PATLAMA! ☢")
            .append(Component.literal(" §7(15 blok yarıçap - sen hasar almadın)")));

        // Client görsel efekti
        PacketHandler.CHANNEL.send(
            PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(
                pos.x, pos.y, pos.z, 64.0, player.level().dimension()
            )),
            new NuclearBlastPacket(pos.x, pos.y, pos.z)
        );
    }

    // ===================== LAZER IŞINI =====================
    private static void fireLaserBeam(ServerPlayer player) {
        Vec3 look = player.getLookAngle();
        Vec3 start = player.getEyePosition();

        for (double dist = 1.0; dist <= 60.0; dist += 0.5) {
            Vec3 point = start.add(look.scale(dist));
            AABB hitBox = new AABB(
                point.x - 0.4, point.y - 0.4, point.z - 0.4,
                point.x + 0.4, point.y + 0.4, point.z + 0.4
            );
            List<LivingEntity> hit = player.level().getEntitiesOfClass(
                LivingEntity.class, hitBox, e -> e != player
            );
            if (!hit.isEmpty()) {
                for (LivingEntity entity : hit) {
                    entity.hurt(player.level().damageSources().playerAttack(player), 40.0f);
                    entity.setSecondsOnFire(5);
                }
                break;
            }
        }
    }

    // ===================== YILDIRIM (STORMFRONT) =====================
    private static void strikeNearbyWithLightning(ServerPlayer player, ServerLevel serverLevel) {
        AABB range = player.getBoundingBox().inflate(12.0);
        List<LivingEntity> nearby = player.level().getEntitiesOfClass(
            LivingEntity.class, range, e -> e != player
        );
        for (LivingEntity entity : nearby) {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(serverLevel);
            if (bolt != null) {
                bolt.moveTo(entity.getX(), entity.getY(), entity.getZ());
                bolt.setVisualOnly(false);
                serverLevel.addFreshEntity(bolt);
            }
        }
    }
}
