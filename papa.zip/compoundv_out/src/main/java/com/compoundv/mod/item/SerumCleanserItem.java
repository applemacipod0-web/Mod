package com.compoundv.mod.item;

import com.compoundv.mod.capability.SuperPowerCapability;
import com.compoundv.mod.network.PacketHandler;
import com.compoundv.mod.network.SyncPowersPacket;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class SerumCleanserItem extends Item {

    public SerumCleanserItem() {
        super(new Item.Properties().stacksTo(16).fireResistant());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (!level.isClientSide()) {
            SuperPowerCapability.get(player).ifPresent(cap -> {

                // Tüm güçleri ve doz sayacını sıfırla
                cap.clearPowers();

                // Uçmayı kapat
                cap.setFlying(false);
                cap.setLaserActive(false);
                cap.setLightningActive(false);
                cap.setNuclearCharged(false);

                player.getAbilities().mayfly = false;
                player.getAbilities().flying = false;
                player.setNoGravity(false);
                player.onUpdateAbilities();

                // Tüm güç efektlerini temizle
                player.removeEffect(MobEffects.DAMAGE_RESISTANCE);
                player.removeEffect(MobEffects.DAMAGE_BOOST);
                player.removeEffect(MobEffects.HEALTH_BOOST);
                player.removeEffect(MobEffects.FIRE_RESISTANCE);
                player.removeEffect(MobEffects.REGENERATION);
                player.removeEffect(MobEffects.MOVEMENT_SPEED);

                // Sesi çal
                level.playSound(null, player.blockPosition(),
                        SoundEvents.BUCKET_EMPTY, SoundSource.PLAYERS, 1.0f, 1.2f);

                // Mesajlar
                player.sendSystemMessage(Component.literal(
                    "§a§l✔ V TEMİZLEYİCİ İÇİLDİ! §r"
                ).withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD));
                player.sendSystemMessage(Component.literal(
                    "§7Tüm Compound V güçleri vücudundan temizlendi."
                ));
                player.sendSystemMessage(Component.literal(
                    "§eArtık tekrar V1 serumu içebilirsin. (0/3)"
                ));

                // Client'a senkronize et
                if (player instanceof ServerPlayer serverPlayer) {
                    PacketHandler.CHANNEL.send(
                        PacketDistributor.PLAYER.with(() -> serverPlayer),
                        new SyncPowersPacket(cap.serializeNBT())
                    );
                }
            });

            stack.shrink(1);
        }

        return InteractionResultHolder.success(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§a§lV TEMİZLEYİCİ").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD));
        tooltip.add(Component.literal("§7Vücudundaki tüm Compound V izlerini temizler.").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.empty());
        tooltip.add(Component.literal("§c• Tüm güçler silinir").withStyle(ChatFormatting.RED));
        tooltip.add(Component.literal("§c• Doz sayacı sıfırlanır (tekrar V1 içebilirsin)").withStyle(ChatFormatting.RED));
        tooltip.add(Component.literal("§c• Uçma, lazer, yıldırım devre dışı kalır").withStyle(ChatFormatting.RED));
        tooltip.add(Component.empty());
        tooltip.add(Component.literal("§e⚗ Serum Maker'da üretilir").withStyle(ChatFormatting.YELLOW));
    }
}
