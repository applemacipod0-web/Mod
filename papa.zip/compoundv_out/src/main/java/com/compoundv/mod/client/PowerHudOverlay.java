package com.compoundv.mod.client;

import com.compoundv.mod.capability.SuperPowerCapability;
import com.compoundv.mod.util.SuperPower;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;

@OnlyIn(Dist.CLIENT)
public class PowerHudOverlay {

    private static final int X       = 6;
    private static final int Y_START = 6;
    private static final int LINE_H  = 11;
    private static final int BAR_W   = 10;

    @SubscribeEvent
    public void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || mc.options.renderDebug) return;

        Player player = mc.player;
        SuperPowerCapability.get(player).ifPresent(cap -> {
            if (cap.getActivePowers().isEmpty()) return;

            GuiGraphics g = event.getGuiGraphics();
            int y = Y_START;

            // ── Güç listesi ──────────────────────────────────────────
            List<String> names = new ArrayList<>();
            for (SuperPower p : cap.getActivePowers()) names.add(shortName(p));
            g.drawString(mc.font, "§f" + String.join(" §7· §f", names), X, y, 0xFFFFFF, true);
            y += LINE_H + 1;

            // ── Nükleer ─────────────────────────────────────────────
            if (cap.hasPower(SuperPower.NUCLEAR_BLAST)) {
                if (cap.isNuclearCharging()) {
                    int pct = Math.min(cap.getNuclearChargeTicks() / 10, 100);
                    g.drawString(mc.font, "§f☢ " + bar(pct, 100), X, y, 0xFFFFFF, true);
                } else if (cap.getNuclearCooldownTicks() > 0) {
                    int pct = (int)(cap.getNuclearCooldownTicks() * 100L / 12000);
                    g.drawString(mc.font, "§f☢ " + bar(pct, 100), X, y, 0xFFFFFF, true);
                } else {
                    g.drawString(mc.font, "§f☢ HAZIR", X, y, 0xFFFFFF, true);
                }
                y += LINE_H;
            }

            // ── Lazer ───────────────────────────────────────────────
            if (cap.hasPower(SuperPower.LASER_EYES) || cap.hasPower(SuperPower.V24_LASER)) {
                int fatigue = cap.getLaserFatigueTicks();
                if (cap.isLaserActive()) {
                    int pct = Math.min(fatigue, 100);
                    g.drawString(mc.font, "§f🔴 " + bar(pct, 100), X, y, 0xFFFFFF, true);
                } else if (fatigue > 0) {
                    int pct = Math.min(fatigue, 60);
                    g.drawString(mc.font, "§f🔴 " + bar(pct, 60), X, y, 0xFFFFFF, true);
                } else {
                    g.drawString(mc.font, "§f🔴 HAZIR", X, y, 0xFFFFFF, true);
                }
                y += LINE_H;
            }

            // ── Yıldırım ────────────────────────────────────────────
            if (cap.hasPower(SuperPower.LIGHTNING_CONTROL)) {
                int cd = cap.getLightningCooldownTicks();
                if (cd > 0) {
                    int pct = (int)(cd * 100L / 200);
                    g.drawString(mc.font, "§f⚡ " + bar(pct, 100), X, y, 0xFFFFFF, true);
                } else {
                    g.drawString(mc.font, "§f⚡ HAZIR", X, y, 0xFFFFFF, true);
                }
                y += LINE_H;
            }

            // ── Uçuş ────────────────────────────────────────────────
            if (cap.hasPower(SuperPower.FLIGHT)) {
                String flyLine = cap.isFlying() ? "§f✈ AKTİF" : "§7✈ kapalı";
                g.drawString(mc.font, flyLine, X, y, 0xFFFFFF, true);
            }
        });
    }

    // Beyaz dolu, koyu gri boş
    private String bar(int current, int max) {
        int filled = Math.round((float) current / max * BAR_W);
        filled = Math.max(0, Math.min(filled, BAR_W));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < BAR_W; i++) {
            sb.append(i < filled ? "§f█" : "§8░");
        }
        return sb.toString();
    }

    private String shortName(SuperPower p) {
        return switch (p) {
            case NEAR_IMMORTALITY  -> "Ölümsüzlük";
            case SUPER_STRENGTH    -> "Süper Güç";
            case FLIGHT            -> "Uçma";
            case SUPER_SPEED       -> "A-Train";
            case LASER_EYES        -> "Lazer";
            case V24_LASER         -> "V24 Lazer";
            case LIGHTNING_CONTROL -> "Yıldırım";
            case ELECTROMAGNETIC   -> "EM Alan";
            case REGENERATION      -> "Yenilenme";
            case STORMFRONT_SHIELD -> "Kalkan";
            case NUCLEAR_BLAST     -> "Nükleer";
            case SOLDIER_SIZE      -> "Soldier";
            default                -> p.displayName;
        };
    }
}
