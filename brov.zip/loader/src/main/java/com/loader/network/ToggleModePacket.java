package com.loader.network;

import com.loader.event.LoaderEventHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class ToggleModePacket {

    public ToggleModePacket() {}

    public static void encode(ToggleModePacket msg, FriendlyByteBuf buf) {}

    public static ToggleModePacket decode(FriendlyByteBuf buf) {
        return new ToggleModePacket();
    }

    public static void handle(ToggleModePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) {
                LoaderEventHandler.get().toggleMode(player);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
