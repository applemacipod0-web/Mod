package com.loader.event;

import com.loader.LoaderMod;
import com.loader.network.PacketHandler;
import com.loader.network.ToggleModePacket;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = LoaderMod.MOD_ID, value = Dist.CLIENT)
public class ClientEventHandler {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        Player player = mc.player;
        ItemStack held = player.getMainHandItem();
        if (!held.is(LoaderMod.LOADER_ITEM.get())) return;

        // FIXED: Server'a paket gönder, direkt çağırma
        while (KeyInputHandler.MODE_KEY != null && KeyInputHandler.MODE_KEY.consumeClick()) {
            PacketHandler.CHANNEL.sendToServer(new ToggleModePacket());
        }
    }
}
