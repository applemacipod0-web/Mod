package com.loader.recipe;

import com.loader.LoaderMod;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

// Tarif JSON dosyaları ile tanımlandığı için bu sınıf şimdilik boş.
// İleride özel tarif tipleri eklenirse buradan register edilir.
public class ModRecipes {
    public static void register(IEventBus bus) {}
}
