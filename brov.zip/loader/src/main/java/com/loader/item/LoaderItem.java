package com.loader.item;

import com.loader.event.LoaderEventHandler;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class LoaderItem extends Item {

    public LoaderItem() {
        super(new Item.Properties().stacksTo(1));
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (!player.isShiftKeyDown()) return InteractionResult.PASS;
        if (player.level().isClientSide()) return InteractionResult.SUCCESS;

        LoaderEventHandler handler = LoaderEventHandler.get();

        if (handler.getMode(player) == LoaderEventHandler.Mode.SINGLE) {
            handler.clearSelection(player);
            handler.selectEntity(player, target);
            player.sendSystemMessage(Component.literal("§aSelected: §f" + target.getName().getString()));
        } else {
            if (handler.isSelected(player, target)) {
                handler.deselectEntity(player, target);
                player.sendSystemMessage(Component.literal("§cDeselected: §f" + target.getName().getString()));
            } else {
                handler.selectEntity(player, target);
                player.sendSystemMessage(Component.literal("§aAdded: §f" + target.getName().getString() + " §7(Total: " + handler.getSelectionCount(player) + ")"));
            }
        }

        return InteractionResult.SUCCESS;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§7Shift+Right Click §f→ Select entity"));
        tooltip.add(Component.literal("§7Shift+Right Click vehicle §f→ Load entity"));
        tooltip.add(Component.literal("§7N key §f→ Single / Multi mode"));
        tooltip.add(Component.literal("§8Recipe: 2 Iron + 3 Chain + 2 Stick"));
    }
}
