package com.loader;

import com.loader.item.LoaderItem;
import com.loader.event.LoaderEventHandler;
import com.loader.network.PacketHandler;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(LoaderMod.MOD_ID)
public class LoaderMod {

    public static final String MOD_ID = "loader";
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final RegistryObject<Item> LOADER_ITEM = ITEMS.register("loader_item", LoaderItem::new);

    public LoaderMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        bus.addListener(this::addCreative);
        bus.addListener(this::commonSetup);
        // FIXED: new LoaderEventHandler() yerine INSTANCE'ı register et
        MinecraftForge.EVENT_BUS.register(LoaderEventHandler.get());
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        PacketHandler.register();
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(LOADER_ITEM);
        }
    }
}
