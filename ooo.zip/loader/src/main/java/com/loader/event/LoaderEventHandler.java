package com.loader.event;

import com.loader.LoaderMod;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;

import java.util.*;

public class LoaderEventHandler {

    public enum Mode { SINGLE, MULTI }

    private static final LoaderEventHandler INSTANCE = new LoaderEventHandler();
    public static LoaderEventHandler get() { return INSTANCE; }

    private final Map<UUID, List<UUID>> selections = new HashMap<>();
    private final Map<UUID, Mode> modes = new HashMap<>();

    public Mode getMode(Player player) {
        return modes.getOrDefault(player.getUUID(), Mode.SINGLE);
    }

    public void toggleMode(Player player) {
        Mode current = getMode(player);
        Mode next = current == Mode.SINGLE ? Mode.MULTI : Mode.SINGLE;
        modes.put(player.getUUID(), next);
        clearSelection(player);
        player.sendSystemMessage(Component.literal(
            next == Mode.SINGLE ? "§eMod: §fTekli" : "§eMod: §fÇoklu"
        ));
    }

    public void selectEntity(Player player, LivingEntity entity) {
        selections.computeIfAbsent(player.getUUID(), k -> new ArrayList<>()).add(entity.getUUID());
    }

    public void deselectEntity(Player player, LivingEntity entity) {
        List<UUID> list = selections.get(player.getUUID());
        if (list != null) list.remove(entity.getUUID());
    }

    public boolean isSelected(Player player, LivingEntity entity) {
        List<UUID> list = selections.get(player.getUUID());
        return list != null && list.contains(entity.getUUID());
    }

    public int getSelectionCount(Player player) {
        List<UUID> list = selections.get(player.getUUID());
        return list == null ? 0 : list.size();
    }

    public void clearSelection(Player player) {
        selections.remove(player.getUUID());
    }

    // FIXED: Araç kapasitesi — tekne 2, minecart 1
    private int getMaxPassengers(Entity vehicle) {
        if (vehicle instanceof Boat) return 2;
        return 1; // AbstractMinecart
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        Player player = event.getEntity();
        Entity target = event.getTarget();

        if (!player.isShiftKeyDown()) return;
        if (event.getHand() != InteractionHand.MAIN_HAND) return;
        if (!player.getMainHandItem().is(LoaderMod.LOADER_ITEM.get())) return;

        boolean isVehicle = target instanceof Boat || target instanceof AbstractMinecart;
        if (!isVehicle) return;

        if (player.level().isClientSide()) {
            event.setCanceled(true);
            return;
        }

        List<UUID> selected = selections.get(player.getUUID());
        if (selected == null || selected.isEmpty()) {
            player.sendSystemMessage(Component.literal("§cHiç canlı seçili değil!"));
            event.setCanceled(true);
            return;
        }

        // FIXED: Araç tipine göre max kapasiteyi kontrol et
        int maxPassengers = getMaxPassengers(target);
        if (target.getPassengers().size() >= maxPassengers) {
            player.sendSystemMessage(Component.literal("§cAraç dolu!"));
            event.setCanceled(true);
            return;
        }

        UUID entityUUID = selected.remove(0);
        Entity toMount = null;
        for (Entity e : player.level().getAllEntities()) {
            if (e.getUUID().equals(entityUUID)) {
                toMount = e;
                break;
            }
        }

        if (toMount != null) {
            toMount.startRiding(target, true);
            player.sendSystemMessage(Component.literal("§a" + toMount.getName().getString() + " §fbindi!"));
        }

        if (!selected.isEmpty()) {
            player.sendSystemMessage(Component.literal("§7Kalan seçili: §f" + selected.size() + " §7(Başka araca tıkla)"));
        } else {
            clearSelection(player);
            player.sendSystemMessage(Component.literal("§7Tüm canlılar bindirildi."));
        }

        event.setCanceled(true);
    }

    @SubscribeEvent
    public void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        selections.remove(event.getEntity().getUUID());
        modes.remove(event.getEntity().getUUID());
    }
}
