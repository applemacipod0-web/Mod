package com.leashable.event;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.monster.hoglin.Hoglin;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.entity.npc.ZombieVillager;
import net.minecraft.world.entity.animal.Turtle;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.LeadItem;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Set;

public class LeashEventHandler {

    // Vanilla'da halata bağlanamayan ama bu modla bağlanabilecek mob sınıfları
    private static final Set<Class<? extends LivingEntity>> LEASHABLE = Set.of(
        Villager.class,
        ZombieVillager.class,
        WanderingTrader.class,
        Witch.class,
        Pillager.class,
        Vindicator.class,
        Evoker.class,
        Turtle.class,
        Creeper.class,
        Zombie.class,
        Skeleton.class,
        EnderMan.class,
        Spider.class,
        Piglin.class,
        Hoglin.class,
        ArmorStand.class
    );

    @SubscribeEvent
    public void onPlayerInteractEntity(PlayerInteractEvent.EntityInteract event) {
        Entity target = event.getTarget();
        var player = event.getEntity();

        // Elinde Lead mi tutuyor?
        if (!player.getMainHandItem().is(Items.LEAD) &&
            !player.getOffhandItem().is(Items.LEAD)) {
            return;
        }

        // Hedef bizim listedeki bir mob mu?
        if (!isLeashableMob(target)) {
            return;
        }

        // Zaten bağlı mı?
        if (target instanceof Mob mob) {
            if (mob.getLeashHolder() != null) return;

            // Halat bağla
            mob.setLeashedTo(player, true);

            // Elindeki Lead'i tüket (creative değilse)
            if (!player.isCreative()) {
                var hand = player.getMainHandItem().is(Items.LEAD)
                    ? net.minecraft.world.InteractionHand.MAIN_HAND
                    : net.minecraft.world.InteractionHand.OFF_HAND;
                player.getItemInHand(hand).shrink(1);
            }

            event.setCanceled(true);
        }
    }

    private boolean isLeashableMob(Entity entity) {
        for (Class<? extends LivingEntity> clazz : LEASHABLE) {
            if (clazz.isInstance(entity)) return true;
        }
        return false;
    }
}
