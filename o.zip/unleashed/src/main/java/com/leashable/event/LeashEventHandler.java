package com.leashable.event;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class LeashEventHandler {

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onInteract(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getEntity().level() instanceof ServerLevel)) return;

        Entity target = event.getTarget();
        if (!(target instanceof Mob mob)) return;

        var player = event.getEntity();
        InteractionHand hand = event.getHand();

        if (!player.getItemInHand(hand).is(Items.LEAD)) return;
        if (mob.getLeashHolder() != null) return;

        mob.setLeashedTo(player, true);

        if (!player.isCreative()) {
            player.getItemInHand(hand).shrink(1);
        }

        event.setCanceled(true);
    }
}
